# Agent Card Template

agent_id: 
name: 
role: 
purpose: 
capabilities:
  - 
allowed_tools:
  - 
forbidden_actions:
  - send_email_without_approval
  - financial_transaction
  - medical_or_legal_advice
risk_limit: A2
memory_scope: workspace_only
requires_review_for:
  - high_impact_claim
  - external_publication
  - long_term_memory_write
kill_conditions:
  - generates_claim_without_evidence
  - attempts_forbidden_tool
  - repeats_same_output_three_times
  - deviates_from_purpose_contract
