# Task Contract Template

task_id: 
objective: 
inputs:
  - 
expected_outputs:
  - 
dependencies:
  - 
risk_level: medium
coordination_mode: supervisor_plus_verifier
acceptance_criteria:
  - all high-impact claims have evidence references
  - dissenting opinions are retained
  - human approval before external action
  - replay bundle export passes audit
