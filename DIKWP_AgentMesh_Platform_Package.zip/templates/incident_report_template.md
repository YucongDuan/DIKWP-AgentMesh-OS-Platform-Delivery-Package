# AgentMesh Incident Report

Incident ID:
Date/Time:
Workspace:
Trigger:
Severity: Low / Medium / High / Critical
Affected agents:
Affected tasks:
Evidence:
Immediate containment:
Root cause:
Recovery action:
Human reviewer:
Residual risk:
Follow-up deadline:
