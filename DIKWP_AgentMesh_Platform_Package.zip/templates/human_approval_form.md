# Human Approval Form

Workspace:
Task:
Action Ticket:
Requested by:
Action Grade: A3 / A4 / A5
External Effect:
Evidence reviewed:
Known risks:
Rollback plan:
Approval decision: Approve / Reject / Request revision
Approver:
Date:
Notes:
