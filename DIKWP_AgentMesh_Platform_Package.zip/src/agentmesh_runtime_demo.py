"""DIKWP-AgentMesh OS local demo runtime.

This file is intentionally offline and deterministic. It demonstrates the
coordination logs, evidence ledger and action gate without calling any LLM API.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import List, Dict, Any
import json

@dataclass
class Agent:
    id: str
    role: str
    risk_limit: str
    capabilities: List[str]
    forbidden_actions: List[str]

@dataclass
class Task:
    id: str
    objective: str
    layer: str
    risk: str
    expected_output: str

class AgentMeshRuntime:
    def __init__(self, purpose: str, agents: List[Agent]):
        if not purpose or len(purpose.strip()) < 10:
            raise ValueError("Purpose Contract is required before collaboration starts.")
        self.purpose = purpose
        self.agents = agents
        self.messages: List[Dict[str, Any]] = []
        self.evidence: List[Dict[str, Any]] = []
        self.claims: List[Dict[str, Any]] = []
        self.decisions: List[Dict[str, Any]] = []
        self.incidents: List[Dict[str, Any]] = []

    def route(self, task: Task) -> Agent:
        role_map = {"D": "Researcher", "I": "Researcher", "K": "Verifier", "W": "Arbiter", "P": "Planner"}
        wanted = role_map.get(task.layer, "Planner")
        for a in self.agents:
            if a.role == wanted:
                return a
        return self.agents[0]

    def log_message(self, sender: str, receiver: str, layer: str, intent: str, content: str, confidence: float = 0.7):
        self.messages.append({
            "message_id": f"msg_{len(self.messages)+1:03d}",
            "time": datetime.now(timezone.utc).isoformat(),
            "sender": sender,
            "receiver": receiver,
            "dikwp_layer": layer,
            "intent": intent,
            "content": content,
            "confidence": confidence,
        })

    def add_evidence(self, claim_id: str, note: str, source: str = "User task contract"):
        ev_id = f"EV{len(self.evidence)+1:03d}"
        self.evidence.append({
            "evidence_id": ev_id,
            "claim_id": claim_id,
            "source_type": "Task Input",
            "source": source,
            "note": note,
            "reliability": "medium",
            "status": "pending",
        })
        return ev_id

    def add_claim(self, statement: str, layer: str, evidence_refs: List[str], owner: str):
        claim_id = f"CL{len(self.claims)+1:03d}"
        self.claims.append({
            "claim_id": claim_id,
            "statement": statement,
            "layer": layer,
            "evidence_refs": evidence_refs,
            "truth_grade": "local",
            "confidence": 0.72,
            "owner_agent": owner,
            "review_status": "draft",
            "kill_condition": "relevant evidence is missing or contradicted",
        })
        return claim_id

    def action_gate(self, requested_by: Agent, action: str, grade: str):
        if grade in {"A3", "A4", "A5"}:
            status = "blocked_pending_human_approval"
        elif any(term in action.lower() for term in ["send", "delete", "pay", "submit", "publish"]):
            status = "blocked_pending_human_approval"
        else:
            status = "allowed_internal"
        ticket = {
            "ticket_id": f"AT{len(self.decisions)+1:03d}",
            "requested_by": requested_by.id,
            "action": action,
            "grade": grade,
            "status": status,
        }
        self.decisions.append(ticket)
        return ticket

    def run(self, tasks: List[Task]):
        for t in tasks:
            agent = self.route(t)
            self.log_message("planner_01", agent.id, t.layer, "assign_task", t.objective)
            cid = f"CL{len(self.claims)+1:03d}"
            ev = self.add_evidence(cid, f"Task objective supports routing: {t.objective}")
            self.add_claim(f"Task {t.id} should be handled by {agent.role}", t.layer, [ev], agent.id)
        # deliberate example high-risk action
        executor = next((a for a in self.agents if a.role == "Executor"), self.agents[0])
        self.action_gate(executor, "Send final external email", "A4")
        return self.replay_bundle()

    def replay_bundle(self):
        return {
            "purpose": self.purpose,
            "agents": [asdict(a) for a in self.agents],
            "messages": self.messages,
            "evidence": self.evidence,
            "claims": self.claims,
            "decisions": self.decisions,
            "incidents": self.incidents,
        }

if __name__ == "__main__":
    agents = [
        Agent("planner_01", "Planner", "A2", ["decompose", "route"], ["external_action"]),
        Agent("research_01", "Researcher", "A2", ["source_search", "summarize"], ["invent_citation"]),
        Agent("verifier_01", "Verifier", "A2", ["check_claims", "find_contradictions"], ["final_decision"]),
        Agent("arbiter_01", "Arbiter", "A3", ["resolve_conflicts"], ["hide_dissent"]),
        Agent("executor_01", "Executor", "A4", ["execute_approved_tools"], ["unapproved_external_action"]),
    ]
    tasks = [
        Task("T001", "Collect credible sources for agent collaboration platform", "D", "medium", "source ledger"),
        Task("T002", "Verify all high-impact architecture claims", "K", "high", "verified claim registry"),
        Task("T003", "Resolve coordination mode conflict", "W", "medium", "decision record"),
    ]
    runtime = AgentMeshRuntime("Build an auditable multi-agent collaboration workspace with human approval for external actions.", agents)
    print(json.dumps(runtime.run(tasks), ensure_ascii=False, indent=2))
