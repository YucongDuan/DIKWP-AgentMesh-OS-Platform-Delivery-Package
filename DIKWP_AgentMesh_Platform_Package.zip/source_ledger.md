# Source Ledger

This delivery package was prepared as a platform blueprint and MVP implementation package. It uses publicly accessible references for conceptual and framework alignment.

1. YucongDuan GitHub ecosystem — https://github.com/YucongDuan
   - Relevance: DIKWP, artificial consciousness, semantic governance, offline prototypes and project packaging.

2. DIKWP-Consciousness-Futures-Studio-V1 — https://github.com/YucongDuan/DIKWP-Consciousness-Futures-Studio-V1
   - Relevance: standalone offline prototype, DIKWP semantic closure, claim levels, evidence ledgers, governance roles, role permissions, kill/recovery matrix and scenario schemas.

3. DIKWP-ProofLedger OS — https://www.researchgate.net/publication/404699131_DIKWP-ProofLedger_OS_Evidence_Ledger_for_AI_Answers_and_Claims
   - Relevance: evidence ledger for AI answers and claims; claim-evidence verification; RAG reliability; report review and output audit.

4. LangGraph — https://www.langchain.com/langgraph
   - Relevance: agent runtime and low-level orchestration framework for complex tasks.

5. AutoGen — https://microsoft.github.io/autogen/stable/
   - Relevance: programming framework for single and multi-agent applications, AgentChat and event-driven multi-agent systems.

6. CrewAI — https://docs.crewai.com/
   - Relevance: collaborative AI agents, crews, flows, guardrails, memory, knowledge and observability.

